let extractedData = [];

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitForPageLoadInTab(tabId) {
    await chrome.scripting.executeScript({
        target: { tabId },
        func: () => new Promise(resolve => {
            if (document.readyState === 'complete') resolve();
            else window.addEventListener('load', resolve, { once: true });
        })
    });
}

function isChecked(id) {
    const el = document.getElementById(id);
    return el && el.checked;
}

async function setCookiesAndExtractData(rawCookiesInput) {
    const lines = rawCookiesInput.split("\n").filter(Boolean);
    extractedData = [];

    for (const line of lines) {
        const [usr, pwd, cookiesString] = line.split("|");
        if (!usr || !pwd || !cookiesString) {
            alert("Invalid input format. Please use 'username|password|cookies' format.");
            continue;
        }
        let cookies = cookiesString.split(";").map(cookieStr => {
            const [name, ...valueParts] = cookieStr.split("=");
            return {
            name: name.trim(),
            value: valueParts.join("=").trim(),
            domain: ".facebook.com",
            path: "/",
            secure: true,
            httpOnly: false,
            sameSite: "lax",
            expirationDate: Math.floor(Date.now() / 1000) + 3600
            };
        });

        const localeIndex = cookies.findIndex(c => c.name === "locale");
        if (localeIndex !== -1) {
            cookies[localeIndex].value = "en_US";
        } else {
            cookies.push({
            name: "locale",
            value: "en_US",
            domain: ".facebook.com",
            path: "/",
            secure: true,
            httpOnly: false,
            sameSite: "lax",
            expirationDate: Math.floor(Date.now() / 1000) + 3600
            });
        }

        await Promise.all(cookies.map(cookie =>
            new Promise(resolve => {
                chrome.cookies.set({ url: "https://www.facebook.com", ...cookie }, () => resolve());
            })
        ));

        await handleTabNavigation(usr, pwd, cookiesString);
    }
}

async function handleTabNavigation(usr, pwd, cookiesString) {
    const tab = await getActiveTab();
    await navigateToUrl(tab.id, "https://www.facebook.com/");
    await waitForPageLoadInTab(tab.id);
    await delay(2000);

    const basicInfo = await executeScript(tab.id, () => {
        const html = document.documentElement.innerHTML;
        const namee = html.match(/"NAME":"([^"]+)","SHORT_NAME"/)?.[1] || "Not found";
        const user_match = html.match(/"id":"(\d+)",\s*"username":"([^"]+)"/);
        const uidMatch = document.cookie.match(/(?:^|;\s*)c_user=([^;]+)/);
        return {
            name: namee,
            username: user_match ? user_match[2] : "Not found",
            uid: uidMatch ? uidMatch[1] : "Not found"
        };
    });

    if (!basicInfo || !basicInfo[0].result || basicInfo[0].result.uid === "Not found") {
        alert("UID not found. Stopping.");
        return;
    }

    const { name, username, uid } = basicInfo[0].result;
    const userData = { user: usr, pass: pwd, cookies: cookiesString };

    if (isChecked("extractName")) userData.name = name;
    if (isChecked("extractUID")) userData.uid = uid;
    if (isChecked("extractProfileURL")) userData.profile_url = `https://www.facebook.com/profile.php?id=${uid}`;
    if (isChecked("extractFollower")) {
        await navigateToUrl(tab.id, `https://www.facebook.com/profile.php?id=${uid}`);
        await waitForPageLoadInTab(tab.id);
        await delay(2000);
        const followerData = await executeScript(tab.id, () => {
            const html = document.documentElement.innerHTML;
            const followerMatch = html.match(/Followed by (\d+) people/);
            return { followers: followerMatch ? followerMatch[1] : "Not found" };
        });
        userData.followers = followerData[0].result.followers;
    }

    if (isChecked("extractFriends")) {
        await navigateToUrl(tab.id, `https://www.facebook.com/profile.php?id=${uid}&sk=friends`);
        await waitForPageLoadInTab(tab.id);
        await delay(2000);
        const friendData = await executeScript(tab.id, () => {
            const link = [...document.querySelectorAll('a')].find(a => a.href.includes("sk=friends") && a.textContent.includes("friend"));
            const frndmatch = link ? link.textContent.match(/\d+/) : null;
            return { friends: frndmatch ? frndmatch[0] : "Not found" };
        });
        userData.friends = friendData[0].result.friends;
    }

    if (isChecked("extractEmail") || isChecked("extractNumber")) {
        await navigateToUrl(tab.id, `https://web.facebook.com/${uid}/about_contact_and_basic_info`);
        await waitForPageLoadInTab(tab.id);
        await delay(2000);
        const contactData = await executeScript(tab.id, () => {
            const html = document.documentElement.innerHTML;
            const phoneMatch = html.match(/"text":"([\+\(]?\d[\d\s\-().]{5,})"},"field_type":"other_phone"/);
            const emailMatch = html.match(/aria-label="[^"]*?([\w.-]+@[\w.-]+\.\w+)[^"]*?"/);
            return {
                phone: phoneMatch ? phoneMatch[1] : "Not found",
                email: emailMatch ? emailMatch[1] : "Not found"
            };
        });
        if (isChecked("extractNumber")) userData.phone = contactData[0].result.phone;
        if (isChecked("extractEmail")) userData.email = contactData[0].result.email;
    }

    extractedData.push(userData);
    await clearFacebookCookies();
    document.getElementById("downloadCSV").style.display = "inline-block";
}

function getActiveTab() {
    return new Promise(resolve => {
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => resolve(tabs[0]));
    });
}

function navigateToUrl(tabId, url) {
    return new Promise(resolve => {
        chrome.tabs.update(tabId, { url }, () => resolve());
    });
}

function executeScript(tabId, func) {
    return new Promise(resolve => {
        chrome.scripting.executeScript({
            target: { tabId },
            func
        }, resolve);
    });
}

function clearFacebookCookies() {
    return new Promise(resolve => {
        chrome.cookies.getAll({ domain: "facebook.com" }, cookies => {
            let count = cookies.length;
            if (count === 0) return resolve();
            for (const cookie of cookies) {
                chrome.cookies.remove({
                    url: `http${cookie.secure ? "s" : ""}://${cookie.domain}${cookie.path}`,
                    name: cookie.name
                }, () => {
                    count--;
                    if (count === 0) resolve();
                });
            }
        });
    });
}

document.addEventListener("DOMContentLoaded", () => {
    const downloadCSVBtn = document.getElementById("downloadCSV");

    document.getElementById("setCookies").onclick = async () => {
        const raw = document.getElementById("cookieInput").value;
        await setCookiesAndExtractData(raw);
    };

    downloadCSVBtn.onclick = () => {
        if (extractedData.length === 0) return alert("No data to export!");

        const headers = Object.keys(extractedData[0]);
        const csvRows = [
            headers.join(","),
            ...extractedData.map(obj => headers.map(h => `"${(obj[h] || "").replace(/"/g, '""')}"`).join(","))
        ];

        const blob = new Blob([csvRows.join("\n")], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "facebook_data.csv";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };
});

const textarea = document.getElementById('cookieInput');
textarea.addEventListener('focus', function () {
    this.style.borderColor = '#4267B2';
});
textarea.addEventListener('blur', function () {
    this.style.borderColor = 'transparent';
});
