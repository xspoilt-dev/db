chrome.runtime.onInstalled.addListener(() => {
  console.log("Facebook Cookie Login extension installed.");
});
