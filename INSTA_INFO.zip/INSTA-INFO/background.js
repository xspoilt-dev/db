chrome.runtime.onInstalled.addListener(() => {
    alert("Extension installed successfully!");
  });