let extractedData = [];

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitForPageLoadInTab(tabId) {
    await chrome.scripting.executeScript({
        target: { tabId },
        func: () => new Promise(resolve => {
            if (document.readyState === 'complete') resolve();
            else window.addEventListener('load', resolve, { once: true });
        })
    });
}

function isChecked(id) {
    const el = document.getElementById(id);
    return el && el.checked;
}

async function setCookiesAndExtractData(rawCookiesInput) {
    const lines = rawCookiesInput.split("\n").filter(Boolean);
    extractedData = [];

    for (const line of lines) {
        const [usr, pwd, cookiesString] = line.split("|");
        if (!usr || !pwd || !cookiesString) {
            alert("Invalid input format! Each line must be: user|pass|cookies");
            continue;
        }

        const cookies = cookiesString.split(";").map(cookieStr => {
            const [name, ...valueParts] = cookieStr.split("=");
            return {
                name: name.trim(),
                value: valueParts.join("=").trim(),
                domain: ".instagram.com",
                path: "/",
                secure: true,
                httpOnly: false,
                sameSite: "lax",
                expirationDate: Math.floor(Date.now() / 1000) + 3600
            };
        });

        await Promise.all(cookies.map(cookie =>
            new Promise(resolve => {
                chrome.cookies.set({ url: "https://www.instagram.com", ...cookie }, () => resolve());
            })
        ));

        await handleInstagramExtraction(usr, pwd, cookiesString);
    }
}

async function handleInstagramExtraction(usr, pwd, cookiesString) {
    const tab = await getActiveTab();

    await navigateToUrl(tab.id, "https://www.instagram.com/");
    await waitForPageLoadInTab(tab.id);
    await delay(2000);

    const profileData = await executeScript(tab.id, () => {
        const html = document.documentElement.innerHTML;
        const username = html.match(/"xdt_viewer":\s*{\s*"user":\s*{\s*"username":"([^"]+)"/)?.[1] || "Not found";
        const bio = html.match(/"biography":"(.*?)"/)?.[1]?.replace(/\\n/g, "\n") || "Not found";
        return { username, bio };
    });

    const result = profileData[0].result;
    const userData = { user: usr, pass: pwd, cookies: cookiesString };

    if (isChecked("extractUsername")) userData.username = result.username;
    if (isChecked("extractBio")) userData.bio = result.bio;

    const profileUrl = `https://www.instagram.com/${result.username}/`;
    await navigateToUrl(tab.id, profileUrl);
    await waitForPageLoadInTab(tab.id);
    await delay(3000);

    const stats = await executeScript(tab.id, () => {
        const html = document.documentElement.innerHTML;
        const metaTag = document.querySelector('meta[property="og:description"]');
        const name = html.match(/"full_name":"([^"]+)"/)?.[1] || "Not found";
        let followers = "Not found";
        let following = "Not found";
        if (metaTag && metaTag.content) {
            const match = metaTag.content.match(/([\d,.]+)\s+Followers?,\s*([\d,.]+)\s+Following/i);
            if (match) {
                followers = match[1].replace(/,/g, '');
                following = match[2].replace(/,/g, '');
            }
        }
        return { followers, following, name };
    });

    if (isChecked("extractName")) userData.fullname = stats[0].result.name;

    if (isChecked("extractFollower")) userData.followers = stats[0].result.followers;
    if (isChecked("extractFollowing")) userData.following = stats[0].result.following;

    // Step 3: Go to Account Center to extract email/phone
    await navigateToUrl(tab.id, "https://accountscenter.instagram.com/personal_info/?theme=dark");
    await waitForPageLoadInTab(tab.id);
    await delay(4000);

    const contactInfo = await executeScript(tab.id, () => {
        const html = document.documentElement.innerText;

        const emailMatch = html.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
        const phoneMatch = html.match(/(?:\+\d{1,3}[\s-]?)?\(?\d{3,4}\)?[\s-]?\d{3,4}[\s-]?\d{3,4}/);
        return {
            email: emailMatch ? emailMatch[0] : "Not found",
            phone: phoneMatch ? phoneMatch[0] : "Not found",
        };
    });

    if (isChecked("extractEmail")) userData.email = contactInfo[0].result.email;
    if (isChecked("extractNumber")) userData.phone = contactInfo[0].result.phone;

    extractedData.push(userData);
    await clearInstagramCookies();
    document.getElementById("downloadCSV").style.display = "inline-block";
}


function getActiveTab() {
    return new Promise(resolve => {
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => resolve(tabs[0]));
    });
}

function navigateToUrl(tabId, url) {
    return new Promise(resolve => {
        chrome.tabs.update(tabId, { url }, () => resolve());
    });
}

function executeScript(tabId, func) {
    return new Promise(resolve => {
        chrome.scripting.executeScript({
            target: { tabId },
            func
        }, resolve);
    });
}

function clearInstagramCookies() {
    return new Promise(resolve => {
        chrome.cookies.getAll({ domain: "instagram.com" }, cookies => {
            let count = cookies.length;
            if (count === 0) return resolve();
            for (const cookie of cookies) {
                chrome.cookies.remove({
                    url: `http${cookie.secure ? "s" : ""}://${cookie.domain}${cookie.path}`,
                    name: cookie.name
                }, () => {
                    count--;
                    if (count === 0) resolve();
                });
            }
        });
    });
}

document.addEventListener("DOMContentLoaded", () => {
    const downloadCSVBtn = document.getElementById("downloadCSV");

    document.getElementById("setCookies").onclick = async () => {
        const raw = document.getElementById("cookieInput").value;
        await setCookiesAndExtractData(raw);
    };

    downloadCSVBtn.onclick = () => {
        if (extractedData.length === 0) return alert("No data to export!");

        const headers = Object.keys(extractedData[0]);
        const csvRows = [
            headers.join(","),
            ...extractedData.map(obj => headers.map(h => `"${(obj[h] || "").replace(/"/g, '""')}"`).join(","))
        ];

        const blob = new Blob([csvRows.join("\n")], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "instagram_data.csv";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };
});
